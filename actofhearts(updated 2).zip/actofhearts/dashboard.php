<?php
session_start();
require_once 'database.php';

// Redirect if not logged in
$userId = $_SESSION['user']['id'] ?? null;
if (!$userId) {
    header("Location: login.php");
    exit;
}

// Get logged-in user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch all posts with user names, profile images and like counts
$postsStmt = $pdo->prepare("
  SELECT 
    posts.*, 
    users.name,
    profile.profile_image,
    (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id) AS like_count,
    (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id AND likes.user_id = ?) AS user_liked
  FROM posts 
  JOIN users ON posts.user_id = users.id 
  LEFT JOIN profile ON posts.user_id = profile.id
  ORDER BY posts.created_at DESC
");
$postsStmt->execute([$userId]);
$posts = $postsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Act of Hearts Dashboard</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to right, #ffd5e5, #ffebf0);
      background-attachment: fixed;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 30px;
      background: linear-gradient(to right, #fbc2eb, #fcd5ce);
      border-bottom: 2px solid #e91e63;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }
    .navbar .logo img {
      height: 50px;
      border-radius: 50%;
    }
    .navbar .search-bar input {
      padding: 10px 20px; 
      border: none;
      border-radius: 15px;
      box-shadow: 0px 2px 5px rgba(233, 30, 99, 0.3);
      outline: none; 
      color: #555;
    }
    .navbar .nav-links a {
      color: #880e4f; 
      margin-left: 20px;
      text-decoration: none;
      font-weight: 600; 
      font-size: 16px;
    }
    .navbar .nav-links a:hover {
      color: #c2185b;
     }
    .content-container {
      background-color: #fff6f9; 
      margin: 30px; 
      padding: 40px 20px;
      border-radius: 25px;
      box-shadow: 0 0 20px rgba(255, 182, 193, 0.3);
    }
    h2 {
      font-size: 32px;
      color: #cc3366;
      text-align: center;
    }

    p {
      font-size: 18px;
      color: #444;
      max-width: 800px;
      margin: 10px auto;
      text-align: center;
    }

    .highlight {
      color: #d6336c;
      font-weight: bold;
    }

    .section-image {
      max-width: 90%;
      height: auto;
      display: block;
      margin: 20px auto;
      border-radius: 10px;
    }

    .image-row {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
    }

    .image-item {
      max-width: 300px;
      text-align: center;
    }

    .image-item img {
      width: 100%;
      border-radius: 10px;
    }

    @media (max-width: 960px) {
      .image-row {
        flex-direction: column;
        align-items: center;
      }

      .image-item {
        max-width: 90%;
      }
    }
    .post-card {
      background-color: #fff;
      border-radius: 12px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin: 20px auto; 
      max-width: 700px;
    }
    .post-header {
      display: flex;
      align-items: center; 
      margin-bottom: 10px;
    }
    .post-header img {
      width: 40px; 
      height: 40px;
      border-radius: 50%; 
      margin-right: 10px;
    }
    .post-title {
      font-weight: bold; 
      font-size: 18px; 
      color: #d6336c; 
     }
    .post-description {
      font-size: 16px;
 	color: #444; 
	margin: 10px 0;
    }
    .post-image {
        width: 100%; 
	max-height: 400px; 
	object-fit: cover;
        border-radius: 10px; 
	margin: 10px 0;
    }
    .post-actions {
        display: flex; 
	justify-content: space-around;
        margin-top: 10px; 
	border-top: 1px solid #eee; 
	padding-top: 10px;
    }
    .post-actions button {
        background: none;
 	border: none; 
	cursor: pointer; 
	font-weight: bold;
    }
    .like-btn { 
	color: #e91e63; 
    }
    .comment-btn { 
	color: #3f51b5; 
    }
    .repost-btn { 
	color: #4caf50; 
    }
#imgModal {
  transition: opacity 0.3s ease;
}
#imgModal img {
  animation: zoomIn 0.3s ease;
}
@keyframes zoomIn {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

  </style>
</head>
<body>
<div class="navbar">
  <div class="logo"><a href="dashboard.php"><img src="images/actofheart.png" alt="Logo"></a></div>
  <div class="search-bar"><input type="text" placeholder="Search good deeds..." /></div>
  <div class="nav-links">
    <a href="index.php">Home</a>
    <a href="friends.php">Friends</a>
    <a href="profile.php">My Profile</a>
    <a href="logout.php">Logout</a>
  </div>
</div>
<div class="content-container">
    <h2>Welcome to Act of Hearts</h2>
    <p>
       A community built on kindness and compassion. At <span class="highlight">Act of Hearts</span>, we celebrate humanity’s most powerful force — doing good. Share, support, and shine a light on the actions that truly matter. Your journey to inspire change starts here.
    </p>
  </section>

  <section>
    <h2>Inspiring Deeds, Real People</h2>
    <p>
      Every act of kindness tells a story. Discover heartfelt tales of strangers helping strangers, communities lifting each other, and everyday heroes who remind us of the good in the world. <span class="highlight">Let their stories move you to action.</span>
    </p>
    <img src="https://images.unsplash.com/photo-1492724441997-5dc865305da7?auto=format&fit=crop&w=900&q=80" alt="People helping each other" class="section-image" />
  </section>

  <section>
    <h2>See the Change Happening Now</h2>
    <p>
      Stay up-to-date with the most recent good deeds shared by users around the world. From food drives to blood donations, witness the impact of collective goodness. <span class="highlight">Post your own act of heart and become part of something bigger.</span>
    </p>
    <img src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80" alt="Community volunteering" class="section-image" />
  </section>

  <section>
    <h2>Meet the Changemakers</h2>
    <p>
      These are the individuals and organizations going above and beyond. Our Top Contributors lead by example, driving causes forward and inspiring others every step of the way. <span class="highlight">Recognize, follow, and connect with them.</span>
    </p>
    <img src="https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=900&q=80" alt="Changemakers" class="section-image" />
  </section>

  <section>
    <h2>Support a Cause You Care About</h2>
    <p>
      Whether it's climate action, education, poverty, or mental health — there's a cause for everyone. <span class="highlight">Dive into real-world initiatives</span> and explore how you can make a tangible difference today.
    </p>
    <div class="image-row">
      <div class="image-item">
        <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80" alt="Climate Action" />
        <p><strong>Climate Action</strong><br />Protecting our planet for future generations.</p>
      </div>
      <div class="image-item">
        <img src="https://images.unsplash.com/photo-1532074205216-d0e1f8ee2c03?auto=format&fit=crop&w=400&q=80" alt="Education" />
        <p><strong>Education</strong><br />Empowering minds to build a better tomorrow.</p>
      </div>
      <div class="image-item">
        <img src="https://images.unsplash.com/photo-1486308510493-cb0a12b9c0af?auto=format&fit=crop&w=400&q=80" alt="Mental Health" />
        <p><strong>Mental Health</strong><br />Supporting wellness and resilience.</p>
      </div>
    </div>
  </section>

  <section>
    <h2>Latest from Our Blog</h2>
    <div class="image-row">
      <div class="image-item">
        <img src="https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=400&q=80" alt="Blog Post 1" />
        <p><strong>Sarah M.</strong><br />How Small Acts Can Create Big Change</p>
      </div>
      <div class="image-item">
        <img src="https://images.unsplash.com/photo-1494172961521-33799ddd43a5?auto=format&fit=crop&w=400&q=80" alt="Blog Post 2" />
        <p><strong>John D.</strong><br />Top 10 Ways to Volunteer Safely</p>
      </div>
      <div class="image-item">
        <img src="https://images.unsplash.com/photo-1486308510493-cb0a12b9c0af?auto=format&fit=crop&w=400&q=80" alt="Blog Post 3" />
        <p><strong>Alice R.</strong><br />The Power of Community Support</p>
      </div>
    </div>
  </section>

  <section>
    <h2>Be the Heart That Acts</h2>
    <p>
      You don’t need a title to be a hero. At Act of Hearts, your smallest action can spark the biggest change. <span class="highlight">Join us in rewriting the world’s story — one good deed at a time.</span>
    </p>
    <img src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=900&q=80" alt="Join the movement" class="section-image" />
  </section><div class="content-container">
  <h2 style="text-align:center; color:#cc3366;">Recent Good Deeds</h2>
  <?php foreach ($posts as $post): ?>
    <div class="post-card">
      <div class="post-header">


<?php
  $profileImage = (!empty($post['profile_image']) && file_exists($post['profile_image'])) 
                  ? $post['profile_image'] 
                  : 'https://i.imgur.com/HLzvH1Z.png';
?>


<img src="<?= htmlspecialchars($profileImage) ?>" alt="user" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">
        <div>
          <strong><?= htmlspecialchars($post['name'] ?? 'Anonymous') ?></strong><br>
          <small><?= date('F j, Y', strtotime($post['created_at'])) ?></small>
        </div>
      </div>
      <?php if (!empty($post['title'])): ?>
        <p class="post-title"><?= htmlspecialchars($post['title']) ?></p>
      <?php endif; ?>
      <?php if (!empty($post['caption'])): ?>
        <p class="post-description"><?= nl2br(htmlspecialchars($post['caption'])) ?></p>
      <?php endif; ?>
      <?php if (!empty($post['description'])): ?>
        <p class="post-description"><?= nl2br(htmlspecialchars($post['description'])) ?></p>
      <?php endif; ?>
      <?php if (!empty($post['image_url'])): ?>
        <img src="<?= htmlspecialchars($post['image_url']) ?>" class="post-image" alt="Post Image">
      <?php endif; ?>

      <!-- Fetch comments -->
      <?php
      $commentStmt = $pdo->prepare("
        SELECT comments.id, comments.user_id, comments.content, users.name, comments.created_at
        FROM comments
        JOIN users ON comments.user_id = users.id
        WHERE comments.post_id = ?
        ORDER BY comments.created_at DESC
      ");
      $commentStmt->execute([$post['id']]);
      $comments = $commentStmt->fetchAll(PDO::FETCH_ASSOC);
      ?>

      <div class="post-actions">
        <button class="like-btn" onclick="likePost(<?= $post['id'] ?>)">
          <?= $post['user_liked'] ? '❤️' : '🤍' ?> <?= $post['like_count'] ?>
        </button>
        <form action="share_post.php" method="GET" style="display:inline;">
          <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
          <button class="repost-btn" type="submit">🔁 Repost</button>
        </form>
      </div>
      <?php if ($post['user_id'] == $userId): ?>
        <button onclick="deletePost(<?= $post['id'] ?>)" style="color:red; background:none; border:none;">🗑️ Delete</button>
      <?php endif; ?>

      <!-- Comments -->
      <div style="margin-top: 15px;">
        <strong style="color: #d6336c;">Comments</strong>
        <?php if ($comments): ?>
          <div style="margin-top:10px;">
            <?php foreach ($comments as $comment): ?>
              <div style="padding:10px; border-bottom:1px solid #eee;">
                <strong style="color: #880e4f;"><?= htmlspecialchars($comment['name']) ?></strong>
                <small style="color:gray; float:right;"><?= date('M d, Y', strtotime($comment['created_at'])) ?></small>
                <?php if ($comment['user_id'] == $userId): ?>
                  <button onclick="deleteComment(<?= $comment['id'] ?>)" style="color:red; background:none; border:none; float:right;">🗑️</button>
                <?php endif; ?>
                <p style="margin:5px 0 0;"><?= nl2br(htmlspecialchars($comment['content'])) ?></p>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p style="color:gray;">No comments yet.</p>
        <?php endif; ?>

        <!-- Add Comment -->
        <form method="POST" action="add_comment.php" style="margin-top: 10px;">
          <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
          <textarea name="content" rows="2" placeholder="Add a comment..." required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 6px; resize: none;"></textarea>
          <button type="submit" style="margin-top: 5px; background-color: #3f51b5; color: white; border: none; padding: 8px 16px; border-radius: 6px;">Post Comment</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<script>
function likePost(postId) {
  fetch('like_post.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'post_id=' + encodeURIComponent(postId)
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    if (data.status === 'success') location.reload();
  });
}

function deletePost(postId) {
  if (confirm("Are you sure you want to delete this post?")) {
    fetch('delete_post.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'post_id=' + encodeURIComponent(postId)
    })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      if (data.status === 'success') location.reload();
    });
  }
}

function deleteComment(commentId) {
  if (confirm("Are you sure you want to delete this comment?")) {
    fetch('delete_comment.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'comment_id=' + encodeURIComponent(commentId)
    })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      if (data.status === 'success') location.reload();
    });
  }
}
 function enlargeImage(src) {
  const modal = document.getElementById('imgModal');
  const modalImage = document.getElementById('modalImage');
  modalImage.src = src;
  modal.style.display = 'flex';
}
  
}
</script>
<!-- Modal for enlarged image -->
<div id="imgModal" onclick="this.style.display='none'"
     style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.8); z-index:10000; justify-content:center; align-items:center;">
  <img id="modalImage" src=""
       style="max-width:90%; max-height:90%; border-radius:10px; box-shadow:0 0 20px rgba(0,0,0,0.5);">
</div>

</body>
</html>

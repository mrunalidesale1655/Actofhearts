<?php
session_start();
require_once 'database.php';

header('Content-Type: application/json');

$userId = $_SESSION['user']['id'] ?? null;
$postId = $_POST['post_id'] ?? null;

if (!$userId || !$postId) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    exit;
}

// Check if already liked
$stmt = $pdo->prepare("SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?");
$stmt->execute([$userId, $postId]);

if ($stmt->fetch()) {
    echo json_encode(['status' => 'error', 'message' => 'Already liked.']);
    exit;
}

// Insert like
$like = $pdo->prepare("INSERT INTO likes (user_id, post_id, created_at) VALUES (?, ?, NOW())");
$like->execute([$userId, $postId]);

echo json_encode(['status' => 'success', 'message' => 'Post liked!']);
